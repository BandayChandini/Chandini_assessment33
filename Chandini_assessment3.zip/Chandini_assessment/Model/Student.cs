﻿namespace StudentAssessment.Model
{
    /*A Finishing School  organization produces different skilled students for IT Corporates all over the country. Companies will recruit their choice of students as per the skills. 
  
Create a application to Register and View the Student details
  
Student will have studentId, name, qualification and skill.  
  
 
  
Build an APP to Complete the following functionalities:
  
1. Register a Student
  
2. List out all Students 
*/
    public class Student1
    {
        public int studentId { get; set; }
        public string name { get; set; }
        public string qualification {  get; set; }
        public string skill {  get; set; }
    }
}
