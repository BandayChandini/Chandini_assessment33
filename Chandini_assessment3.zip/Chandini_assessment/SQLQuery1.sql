CREATE DATABASE ASSESSMENT3



use ASSESSMENT3

CREATE TABLE [Subject] (
    subjectId INT PRIMARY KEY,
    subtitle VARCHAR(20) NOT NULL
);
select * from Subject


CREATE TABLE Books (
    bookId INT PRIMARY KEY,
    title VARCHAR(20) NOT NULL,
    price INT NOT NULL,
    volume INT,
    author VARCHAR(20) NOT NULL,
    publishDate DATE,
    subjectId INT,
    FOREIGN KEY (subjectId) REFERENCES Subject(subjectId)
);



INSERT INTO Subject  VALUES (1, 'ABC');
INSERT INTO Subject  VALUES (2, 'ABD');
INSERT INTO Subject  VALUES (3, 'ABE');
INSERT INTO Subject  VALUES (4, 'ABF');
INSERT INTO Subject  VALUES (5, 'ABG');



INSERT INTO Books  VALUES (1, 'abc', 40, 1, 'XYZ', '2024-03-01', 1);
INSERT INTO Books  VALUES (2, 'abd', 45, 2, 'PQR', '2023-03-10', 2);
INSERT INTO Books  VALUES (3, 'abe', 55, 1, 'XYP', '2023-07-01', 3);
INSERT INTO Books VALUES (4, 'abf', 60, 1, 'abc', '2023-05-01', 2);
INSERT INTO Books VALUES (5, 'abg', 65, 1, 'abd', '2023-05-10', 2);
INSERT INTO Books VALUES (6, 'abh', 70, 2, 'abe', '2023-06-01', 2);
INSERT INTO Books  VALUES (7, 'abi', 50, 1, 'abf', '2023-06-15', 3);
INSERT INTO Books  VALUES (8, 'abj', 55, 1, 'abg', '2023-07-01', 3);
INSERT INTO Books  VALUES (9, 'abk', 60, 2, 'abc', '2023-07-15', 3);
INSERT INTO Books VALUES (10, 'abl', 45, 1, 'abv', '2023-08-01', 4);
INSERT INTO Books  VALUES (11, 'abm', 50, 1, 'abg', '2023-08-15', 4);
INSERT INTO Books VALUES (12, 'abn', 55, 2, 'abh', '2023-09-01', 4);
INSERT INTO Books  VALUES (13, 'abc', 40, 1, 'pqr', '2023-09-15', 5);
INSERT INTO Books  VALUES (14, 'abd', 50, 1, 'pqs', '2023-10-01', 5);
INSERT INTO Books VALUES (15, 'abe', 60, 2, 'pqt', '2023-10-15', 5);


select * from Books

select b.bookId,b.title,b.volume,b.subjectId,b.price,b.author,b.publishDate,s.subtitle
from [Subject] as s
inner join Books as b
on s.subjectId=b.subjectId
SELECT bookId, title, price, volume, author, publishDate, subjectId
FROM Books
WHERE publishDate BETWEEN '2023-01-01' AND '2023-06-30';
SELECT author, COUNT(*) AS numberOfBooks
FROM Books
GROUP BY author;
select s.subtitle AS subject, COUNT(b.bookId) AS numberOfBooks
from Books b
JOIN Subject s ON b.subjectId = s.subjectId
group  by s.subtitle;
select COUNT(*) AS numberOfBooks
from Books
where Year(publishDate) = 2000;


update Books
set price = 55, volume = 3
where bookId = 1;


update Books
set price = price * 1.10
where subjectId = (
    select subjectId
    from Subject
    where subtitle = 'abc'
);


delete from Books
where bookId = 12;


select b.bookId, b.title, b.price, s.subtitle as subject
from Books b
JOIN Subject s ON b.subjectId = s.subjectId
where b.price > 500
  AND s.subtitle = 'abd';


select b.bookId, b.title, b.price, b.volume, b.author, b.publishDate, s.subtitle as subject
from Books b
JOIN Subject s ON b.subjectId = s.subjectId
Order by s.subtitle ASC;


select bookId, title, price,  subjectId
from Books
where price = (select MIN(price) from Books);


select bookId, title, price
from Books
where price = (select MIN(price) from Books);



select COUNT(*) AS numberOfBooks
from Books b
JOIN Subject s on b.subjectId = s.subjectId
where s.subtitle = 'abc';


select b.bookId, b.title, b.price, b.volume, b.author, b.publishDate, s.subtitle as subject
from Books b
JOIN Subject s on b.subjectId = s.subjectId
where s.subtitle IN ('Physics', 'Mathematics', 'Computer Science');

