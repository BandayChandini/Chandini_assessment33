using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using StudentAssessment.Model;
namespace Student.Pages
{
    public class Student_detailsModel : PageModel
    {
        

        static List<Student1> students = new List<Student1>()
        {
            new Student1(){studentId=1,name="abc",qualification="btech",skill="frontend"},
            new Student1(){studentId=2,name="abd",qualification="mtech",skill="backend"},
            new Student1(){studentId=3,name="abe",qualification="MBA",skill="fullstack"},
            new Student1(){studentId=4,name="abf",qualification="btech",skill="frontend"},
            new Student1(){studentId=5,name="abg",qualification="MBA",skill="backend"},
        };
        [BindProperty]
        public Student1 Student { get; set; }
    
        public List<Student1> List
        {
            get { return students; }
        }
        public void OnGet()
        {

        }
        public IActionResult OnPost()
        {
            students.Add(Student);
            return RedirectToPage("Student");
        }
        
    }
}
